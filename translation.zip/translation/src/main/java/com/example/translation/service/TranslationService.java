package com.example.translation.service;

import com.example.translation.entity.Translation;
import com.example.translation.repository.TranslationRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class TranslationService {
    private final TranslationRepository repository;

    public List<Translation> getAll() {
        return repository.findAll();
    }

    public Translation save(Translation translation) {
        return repository.save(translation);
    }

    public List<Translation> search(String query) {
        return repository.findByKeyContainingIgnoreCaseOrValueContainingIgnoreCase(query, query);
    }
    public Translation contextTag(String query) {
        return repository.findByContextTag(query);
    }

    public List<Translation> getByLocale(String locale) {
        return repository.findByLocale(locale);
    }
}
