package com.example.translation.controller;

import com.example.translation.auth.JwtUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class AuthController {
    private final JwtUtil jwtUtil;

    @PostMapping("/login")
    public Map<String, String> login(@RequestParam String username) {
        // In a real app, you'd validate username/password
        String token = jwtUtil.generateToken(username);
        return Map.of("token", token);
    }
}
