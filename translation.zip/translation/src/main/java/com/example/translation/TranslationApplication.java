package com.example.translation;

import com.example.translation.entity.Translation;
import com.example.translation.repository.TranslationRepository;
import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Info;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import java.util.HashSet;
import java.util.Random;
import java.util.Set;
import java.util.stream.IntStream;

@SpringBootApplication
@OpenAPIDefinition(info = @Info(title = "Translation Service API", version = "1.0", description = "API for managing translations"))
public class TranslationApplication {
	public static void main(String[] args) {
		SpringApplication.run(TranslationApplication.class, args);
	}


	@Bean
	CommandLineRunner seedDatabase(TranslationRepository repository) {
		return args -> {
			if (repository.count() < 100000) {
				String[] locales = {"en", "fr", "es", "de", "it"};
				String[] tags = {"web", "mobile", "desktop"};
				Random random = new Random();

				IntStream.range(0, 100000).parallel().forEach(i -> {
					Translation t = new Translation();
					t.setLocale(locales[random.nextInt(locales.length)]);
					t.setKey("key_"+t.getLocale() );
					t.setValue("value_"+t.getLocale());
					t.setContextTag(tags[random.nextInt(tags.length)]);
					repository.save(t);
				});
			}
		};
	}
}
