package com.example.translation.controller;
import com.example.translation.entity.Translation;
import com.example.translation.service.TranslationService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/translations")
@RequiredArgsConstructor
public class TranslationController {
    private final TranslationService service;

    @GetMapping
    public List<Translation> getAll() {
        return service.getAll();
    }

    @PostMapping("/save")
    public Translation create(@RequestBody Translation translation) {
        return service.save(translation);
    }

    @GetMapping("/search")
    public List<Translation> search(@RequestParam String q) {
        return service.search(q);
    }
    @GetMapping("/search")
    public Translation contexTag(@RequestParam String q) {
        return service.contextTag(q);
    }

    @GetMapping("/export/{locale}")
    public List<Translation> exportByLocale(@PathVariable String locale) {
        return service.getByLocale(locale);
    }
}
