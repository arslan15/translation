package com.example.translation.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "translations", indexes = {
        @Index(columnList = "locale,key"),
        @Index(columnList = "contextTag"),
        @Index(columnList = "value")
})
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Translation {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String locale;

    private String key;

    @Column(length = 2000)
    private String value;

    private String contextTag;
}
