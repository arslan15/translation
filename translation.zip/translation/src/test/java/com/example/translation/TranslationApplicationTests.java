package com.example.translation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TranslationApplicationTests {

	@Test
	void contextLoads() {
	}

}
