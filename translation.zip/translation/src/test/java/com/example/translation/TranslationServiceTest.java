package com.example.translation;

import com.example.translation.entity.Translation;
import com.example.translation.repository.TranslationRepository;
import com.example.translation.service.TranslationService;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;


class TranslationServiceTest {

    @Test
    void shouldReturnTranslationsByLocale() {
        var repo = mock(TranslationRepository.class);
        var service = new TranslationService(repo);

        when(repo.findByLocale("en")).thenReturn(List.of(
                new Translation(1L, "en", "greeting", "Hello", "web")
        ));

        List<Translation> results = service.getByLocale("en");
        assertEquals(1, results.size());
        assertEquals("Hello", results.get(0).getValue());
    }
}
