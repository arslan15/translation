import com.example.translation.TranslationApplication;
import com.example.translation.entity.Translation;
import com.example.translation.repository.TranslationRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.stereotype.Component;
import org.springframework.test.web.servlet.MockMvc;

import static org.hamcrest.Matchers.hasSize;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest(classes = TranslationApplication.class)

@AutoConfigureMockMvc
class TranslationControllerTest {
@Autowired
     private MockMvc mockMvc;
@Autowired
    private TranslationRepository repo;

    @BeforeEach
    void setup() {
        repo.deleteAll();
        repo.save(new Translation(null, "en", "hello", "Hello", "web"));
        repo.save(new Translation(null, "fr", "hello", "Bonjour", "mobile"));
    }

    @Test
    void shouldExportTranslationsByLocale() throws Exception {
        mockMvc.perform(get("/api/translations/export/en"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(1)));
    }

    @Test
    void shouldSearchTranslations() throws Exception {
        mockMvc.perform(get("/api/translations/search?q=hello"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(2)));
    }

    @Test
    void exportShouldCompleteUnder500ms() throws Exception {
        long start = System.currentTimeMillis();

        mockMvc.perform(get("/api/translations/export/en"))
                .andExpect(status().isOk());

        long duration = System.currentTimeMillis() - start;

        // Correct assertion
        assertTrue(duration < 500, "Export took too long: " + duration + "ms");
    }

    @Test
    void searchByTagShouldBeFast() throws Exception {
        long start = System.currentTimeMillis();

        mockMvc.perform(get("/api/translations/search?q=web"))
                .andExpect(status().isOk());

        long duration = System.currentTimeMillis() - start;

        // Correct assertion
        assertTrue(duration < 200, "Search by tag took too long: " + duration + "ms");
    }

}
